package starter.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.Home;
import starter.login.Login;
import starter.login.Product;

public class ProductSteps {
    @Steps
    Login login;

    @Steps
    Home home;

    @Steps
    Product product;

    @Given("I am on the home page")
    public void onHomePage(){
        login.openUrl("https://www.sepulsa.com/");
        home.validateOnTheHomePage();
    }
    @When("I click on the Pulsa button")
    public void clickPulsaButton(){
        product.pulsaButton();
    }
    @And("I enter my valid phone number")
    public void enterValidNumber(){
        product.inputNumber("082234842641");
    }
    @Then("I should be able to choose a product")
    public void chooseProduct(){
        product.clickProduct();
    }
    @And("The redirected to the payment method")
    public void redirectToPaymentPage(){
        product.onThePaymentPage();
    }
}
