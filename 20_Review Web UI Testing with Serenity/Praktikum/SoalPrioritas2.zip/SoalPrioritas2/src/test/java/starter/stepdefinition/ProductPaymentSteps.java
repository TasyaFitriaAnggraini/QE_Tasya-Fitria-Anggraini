package starter.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.Login;
import starter.login.Product;
import starter.login.ProductPayment;

public class ProductPaymentSteps {
    @Steps
    Login login;

    @Steps
    Product product;

    @Steps
    ProductPayment payment;

    @Given("I have already chosen a product")
    public void alreadyChooseProduct(){
        login.openUrl("https://www.sepulsa.com/");
        product.pulsaButton();
        product.inputNumber("082234842641");
        product.clickProduct();
    }
    @When("I enter my email")
    public void enterGuestEmail(){
        payment.enterEmail("wiyanherra@gmail.com");
    }
    @And("I enter valid phone number")
    public void enterGuestNumber(){
        payment.enterNumber("082234842641");
    }
    @Then("I click on the payment method")
    public void clickPayMethod(){
        payment.clickPayMethod();
    }
    @And("I click on the pay button")
    public void clickPayButton(){
        payment.clickPay();
    }
}
