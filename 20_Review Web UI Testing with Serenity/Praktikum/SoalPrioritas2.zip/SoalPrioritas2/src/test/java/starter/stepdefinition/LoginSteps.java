package starter.stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.login.Home;
import starter.login.Login;

public class LoginSteps {
    @Steps
    Login login;

    @Steps
    Home home;

    //Scenario: [Positive] - Successful login
    @Given("I am on the login page")
    public void onTheLoginPage(){
        login.openUrl("https://www.sepulsa.com/signin");
        login.validateOnLoginPage();
    }
    @When("I enter a valid username")
    public void enterValidUsername(){
        login.inputUsername("tasyafitriaanggraini18@students.unnes.ac.id");
    }
    @And("I enter valid password")
    public void enterValidPassword(){
        login.inputPassword("Sezzle2021");
    }
    @And("I click login button")
    public void clickLoginButton(){
        login.ClickLoginButton();
    }
    @Then("I should be directed to the home page")
    public void onTheHomePage(){
        home.validateOnTheHomePage();
    }

    //Scenario: [Negative] - Unsuccessful login
    @Given("I am on the web login page")
    public void onTheWebLoginPage(){
        login.openUrl("https://www.sepulsa.com/signin");
        login.validateOnLoginPage();
    }
    @When("I enter an invalid username")
    public void enterInalidUsername(){
        login.inputUsername("wiyanherraherviana@gmail.co");
    }
    @And("I enter an valid password")
    public void enterValidUserPassword(){
        login.inputPassword("@MSIBatch4Alterra");
    }
    @And("I click the login button")
    public void clickTheLoginButton(){
        login.ClickLoginButton();
    }
    @Then("I should see an error message")
    public void warningMessage(){
        login.warningMessage();
    }
}
