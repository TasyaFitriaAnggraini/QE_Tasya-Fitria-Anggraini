package starter.login;

import net.serenitybdd.screenplay.actions.OpenUrl;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

public class ProductPayment extends PageObject {
    private By guestEmail(){
        return By.name("user.email");
    }
    private By guestPassword(){
        return By.name("user.phone");
    }
    private By pay(){
        return By.className("MuiButton-label");
    }
    private By method(){return By.id("checkbox Gopay");}
    private By dana(){return By.className("button-deepLink");}

    @Step
    public static OpenUrl url(String targeturl){
        return new OpenUrl(targeturl);
    }
    @Step
    public void enterEmail(String guestEmail){
        $(guestEmail()).type(guestEmail);
    }
    public void enterNumber(String guestPassword){
        $(guestPassword()).type(guestPassword);
    }
    @Step
    public void clickPayMethod(){
        $(method()).click();
    }
    @Step
    public void clickPay(){
        $(pay()).click();
    }
}
