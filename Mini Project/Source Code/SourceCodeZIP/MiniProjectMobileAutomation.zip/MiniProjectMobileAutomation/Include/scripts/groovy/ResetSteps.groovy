import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When



class ResetSteps {

	//Scenario Outline: Reset Successfully Item
	@Given("user open the apk shopping list")
	public void openedShoppiingListApplication() {
		Mobile.startApplication('/Users/Lenovo/Downloads/app-debug.apk', true)
	}

	@When("user taped the add button")
	def tapedAddButton() {
		Mobile.tap(findTestObject('Object Repository/object/add button'), 0)
	}

	@And("user taped the dropbox name and input name as the nanas")
	def tapedDropdownNameAndInputName() {
		Mobile.tap(findTestObject('Object Repository/object/dropbox name'), 0)
		Mobile.setText(findTestObject('Object Repository/object/input name'), 'Nanas', 0)
	}

	@And("user taped the quantity and enter 5 in the inpquantity")
	def tapedQuantityAndEnterQuantity() {
		Mobile.tap(findTestObject('Object Repository/object/quantity'), 0)
		Mobile.setText(findTestObject('Object Repository/object/inpquantity'), '5', 0)
	}

	@And("user taped dropdown and user taped fruit categories")
	def tapedDropdownAndFruitCategories() {
		Mobile.tap(findTestObject('Object Repository/object/dropdown'), 0)
		Mobile.tap(findTestObject('Object Repository/object/categories'), 0)
	}

	@Then("user is successfully reset item")
	def verifyResetSuccessfully() {
		// Perform verification steps to check if the item was successfully added
		// You may need to add additional verification steps here
		Mobile.verifyElementVisible(findTestObject('Object Repository/object/reset button'), 0)

		// Close the application
		Mobile.closeApplication()
	}
	
	// Reset Successfully Item Empty Name Item
	@Given("user opened the apk shopping list")
	public void openeddShoppiingListApplication() {
		Mobile.startApplication('/Users/Lenovo/Downloads/app-debug.apk', true)
	}

	@When("userr taped the add button")
	def tapeddAddButton() {
		Mobile.tap(findTestObject('Object Repository/object/add button'), 0)
	}

	@And("userr taped the dropbox name and empty name")
	def tapeddDropdownNameAndInputName() {
		Mobile.tap(findTestObject('Object Repository/object/dropbox name'), 0)
	}

	@And("userr taped the quantity and enter 5 in the inpquantity")
	def tapeddQuantityAndEnterQuantity() {
		Mobile.tap(findTestObject('Object Repository/object/quantity'), 0)
		Mobile.setText(findTestObject('Object Repository/object/inpquantity'), '5', 0)
	}

	@And("userr taped dropdown and userr taped fruit categories")
	def tapeddDropdownAndFruitCategories() {
		Mobile.tap(findTestObject('Object Repository/object/dropdown'), 0)
		Mobile.tap(findTestObject('Object Repository/object/categories'), 0)
	}

	@Then("userr is successfully reset item")
	def verifyyResetSuccessfully() {
		// Perform verification steps to check if the item was successfully added
		// You may need to add additional verification steps here
		Mobile.verifyElementVisible(findTestObject('Object Repository/object/reset button'), 0)

		// Close the application
		Mobile.closeApplication()
	}
	
	// Reset Successfully Item Empty Quantity
	@Given("userr opened the apk shopping list")
	public void openedddShoppiingListApplication() {
		Mobile.startApplication('/Users/Lenovo/Downloads/app-debug.apk', true)
	}

	@When("userr tapedd the add button")
	def tapedddAddButton() {
		Mobile.tap(findTestObject('Object Repository/object/add button'), 0)
	}

	@And("userr tapedd the dropbox name and input name as the nanas")
	def tapedddDropdownNameAndInputName() {
		Mobile.tap(findTestObject('Object Repository/object/dropbox name'), 0)
		Mobile.setText(findTestObject('Object Repository/object/input name'), 'Nanas', 0)
	}

	@And("userr tapedd the quantity and empty quantity")
	def tapedddQuantityAndEnterQuantity() {
		Mobile.tap(findTestObject('Object Repository/object/quantity'), 0)
		Mobile.setText(findTestObject('Object Repository/object/inpquantity'), "", 0)
	}

	@And("userr tapedd dropdown and userr tapedd fruit categories")
	def tapedddDropdownAndFruitCategories() {
		Mobile.tap(findTestObject('Object Repository/object/dropdown'), 0)
		Mobile.tap(findTestObject('Object Repository/object/categories'), 0)
	}

	@Then("userr is successfullyy reset item")
	def verifyyyResetSuccessfully() {
		// Perform verification steps to check if the item was successfully added
		// You may need to add additional verification steps here
		Mobile.verifyElementVisible(findTestObject('Object Repository/object/reset button'), 0)

		// Close the application
		Mobile.closeApplication()
	}
	
	// Reset Successfully Item Empty Name and Quantity
	@Given("userr openedd the apk shopping list")
	public void openedddShoppiinggListApplication() {
		Mobile.startApplication('/Users/Lenovo/Downloads/app-debug.apk', true)
	}

	@When("userr tapedd the add buttonn")
	def tapedddAddButtonn() {
		Mobile.tap(findTestObject('Object Repository/object/add button'), 0)
	}

	@And("userr tapedd the dropbox name and emptyy namee")
	def tapedddDropdownnNameAndInputName() {
		Mobile.tap(findTestObject('Object Repository/object/dropbox name'), 0)
	}

	@And("userr tapedd the quantity and emptyy quantityy")
	def tapedddQuantityyAndEnterQuantity() {
		Mobile.tap(findTestObject('Object Repository/object/quantity'), 0)
		Mobile.setText(findTestObject('Object Repository/object/inpquantity'), "", 0)
	}

	@And("userr tapedd dropdownn and userr tapedd fruit categoriess")
	def tapedddDropdownnAndFruitCategories() {
		Mobile.tap(findTestObject('Object Repository/object/dropdown'), 0)
		Mobile.tap(findTestObject('Object Repository/object/categories'), 0)
	}

	@Then("userr is successfullyy reset itemm")
	def verifyyyResetSuccessfullyy() {
		// Perform verification steps to check if the item was successfully added
		// You may need to add additional verification steps here
		Mobile.verifyElementVisible(findTestObject('Object Repository/object/reset button'), 0)

		// Close the application
		Mobile.closeApplication()
	}
}