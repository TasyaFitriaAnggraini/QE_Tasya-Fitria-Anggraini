import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When

public class AddItemSteps {

	//Scenario Outline: Valid Add an item to the list
	@Given("user oppened the shooping list aplication")
	public void openShoppingListApplication() {
		Mobile.startApplication('/Users/Lenovo/Downloads/app-debug.apk', true)
	}

	@When("i tap the add button")
	def tapAddButton() {
		Mobile.tap(findTestObject('Object Repository/object/add button'), 0)
	}

	@And("i tap the dropbox name and input name as the nanas")
	def tapDropdownNameAndInputName() {
		Mobile.tap(findTestObject('Object Repository/object/dropbox name'), 0)
		Mobile.setText(findTestObject('Object Repository/object/input name'), 'Nanas', 0)
	}

	@And("I tap the quantity and enter 5 in the inpquantity")
	def tapQuantityAndEnterQuantity() {
		Mobile.tap(findTestObject('Object Repository/object/quantity'), 0)
		Mobile.setText(findTestObject('Object Repository/object/inpquantity'), '5', 0)
	}

	@And("I tap dropdown and I tap fruit categories")
	def tapDropdownAndFruitCategories() {
		Mobile.tap(findTestObject('Object Repository/object/dropdown'), 0)
		Mobile.tap(findTestObject('Object Repository/object/categories'), 0)
	}

	@Then("User is successfully add item")
	def verifyItemAddedSuccessfully() {
		// Perform verification steps to check if the item was successfully added
		// You may need to add additional verification steps here
		Mobile.verifyElementVisible(findTestObject('Object Repository/object/add item button'), 0)

		// Close the application
		Mobile.closeApplication()
	}


	// Scenario Outline: InValid Add an Item to the List
	@Given("user open the shopping app")
	public void openShooppingListApplication() {
		Mobile.startApplication('/Users/Lenovo/Downloads/app-debug.apk', true)
	}

	@When("user tap add button")
	def tappAddButton() {
		Mobile.tap(findTestObject('Object Repository/object/add button'), 0)
	}

	@And("user tap dropbox name")
	def tappDropdownNameAndInputName() {
		Mobile.tap(findTestObject('Object Repository/object/dropbox name'), 0)
	}

	@And("user tap quantity and input 5 inpquantity")
	def tappQuantityAndEnterQuantity() {
		Mobile.tap(findTestObject('Object Repository/object/quantity'), 0)
		Mobile.setText(findTestObject('Object Repository/object/inpquantity'), '5', 0)
	}

	@And("user click dropdown and user clik categories fruit")
	def tappDropdownAndFruitCategories() {
		Mobile.tap(findTestObject('Object Repository/object/dropdown'), 0)
		Mobile.tap(findTestObject('Object Repository/object/categories'), 0)
	}

	@Then("user is unsuccessfully add item")
	def verifyyItemAddedSuccessfully() {
		// Perform verification steps to check if the item was successfully added
		// You may need to add additional verification steps here
		Mobile.verifyElementVisible(findTestObject('Object Repository/object/add item button'), 0)

		// Close the application
		Mobile.closeApplication()
	}

	// InValid Add Item to the List because empty Quantity
	@Given("user openn the shopping app")
	public void openedShooppingListApplication() {
		Mobile.startApplication('/Users/Lenovo/Downloads/app-debug.apk', true)
	}

	@When("user click add button")
	def tapAddeddButton() {
		Mobile.tap(findTestObject('Object Repository/object/add button'), 0)
	}

	@And("user click dropbox name and input name item")
	def tapDropdownnnNameAndInputName() {
		Mobile.tap(findTestObject('Object Repository/object/dropbox name'), 0)
		Mobile.setText(findTestObject('Object Repository/object/input name'), 'Nanas', 0)
	}

	@And("user click quantity and empty quantity")
	def tapQuantityyyAndEnterQuantity() {
		Mobile.tap(findTestObject('Object Repository/object/quantity'), 0)
		Mobile.setText(findTestObject('Object Repository/object/inpquantity'), "", 0)
	}

	@And("user clickk dropdown and user clikk categories fruit")
	def tapDropdownedAndFruitCategories() {
		Mobile.tap(findTestObject('Object Repository/object/dropdown'), 0)
		Mobile.tap(findTestObject('Object Repository/object/categories'), 0)
	}

	@Then("user is unsuccessfully added item")
	def verifyItemAddeddSuccessfully() {
		// Perform verification steps to check if the item was successfully added
		// You may need to add additional verification steps here
		Mobile.verifyElementVisible(findTestObject('Object Repository/object/add item button'), 0)

		// Close the application
		Mobile.closeApplication()
	}

	// InValid Add Item to the List because empty Name Item and Quantity
	@Given("user openeed the shopping app")
	public void opennShooppingListApplication() {
		Mobile.startApplication('/Users/Lenovo/Downloads/app-debug.apk', true)
	}

	@When("user click added button")
	def tapAddedButton() {
		Mobile.tap(findTestObject('Object Repository/object/add button'), 0)
	}

	@And("user click dropbox name and empty name")
	def tapDropdownnNameAndInputName() {
		Mobile.tap(findTestObject('Object Repository/object/dropbox name'), 0)
	}

	@And("user clickedd quantity and empty quantity")
	def tapQuantityyAndEnterQuantity() {
		Mobile.tap(findTestObject('Object Repository/object/quantity'), 0)
		Mobile.setText(findTestObject('Object Repository/object/inpquantity'), "", 0)
	}

	@And("user clicked dropdown and user cliked categories fruit")
	def tapDropdownnAndFruitCategories() {
		Mobile.tap(findTestObject('Object Repository/object/dropdown'), 0)
		Mobile.tap(findTestObject('Object Repository/object/categories'), 0)
	}

	@Then("userr is unsuccessfully added item")
	def verifyItemmAddedSuccessfully() {
		// Perform verification steps to check if the item was successfully added
		// You may need to add additional verification steps here
		Mobile.verifyElementVisible(findTestObject('Object Repository/object/add item button'), 0)

		// Close the application
		Mobile.closeApplication()
	}

	// InValid Add Item to the List because Quantity "0"
	@Given("user openeeded the shopping app")
	public void opennShooppinggListApplication() {
		Mobile.startApplication('/Users/Lenovo/Downloads/app-debug.apk', true)
	}

	@When("user clicked added button")
	def tappAddedButton() {
		Mobile.tap(findTestObject('Object Repository/object/add button'), 0)
	}

	@And("user clicked dropbox name and entered name")
	def tappDropdownnNameAndInputName() {
		Mobile.tap(findTestObject('Object Repository/object/dropbox name'), 0)
		Mobile.setText(findTestObject('Object Repository/object/input name'), 'Nanas', 0)

	}

	@And("user clicked quantity and 0 quantity")
	def tappQuantityyAndEnterQuantity() {
		Mobile.tap(findTestObject('Object Repository/object/quantity'), 0)
		Mobile.setText(findTestObject('Object Repository/object/inpquantity'), 0, 0)
	}

	@And("user clickedd dropdown and user clikedd categories fruit")
	def tappDropdownnAndFruitCategories() {
		Mobile.tap(findTestObject('Object Repository/object/dropdown'), 0)
		Mobile.tap(findTestObject('Object Repository/object/categories'), 0)
	}

	@Then("userr is unsuccessfully added item because 0 quantity")
	def verifyyItemmAddedSuccessfully() {
		// Perform verification steps to check if the item was successfully added
		// You may need to add additional verification steps here
		Mobile.verifyElementVisible(findTestObject('Object Repository/object/add item button'), 0)

		// Close the application
		Mobile.closeApplication()
	}
}

